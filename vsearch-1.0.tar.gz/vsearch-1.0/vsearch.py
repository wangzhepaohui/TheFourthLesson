def search4letters(phrase:str,letters:str='aeiou')->set:
    '''
    Return a set of 'letters'  found in a 'phrase'
    '''
    return set(letters).intersection(set(phrase))

def search4vowels(word:str)->set:
    '''
    Return a set of 'letters'  found in a 'phrase'
    '''
    vowels = set('aeiou')
    return vowels.intersection(set(word))